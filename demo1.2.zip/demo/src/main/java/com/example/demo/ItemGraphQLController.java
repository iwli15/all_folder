package com.foodapp.catalogservice;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@RestController
@RequestMapping("/api/catalog")
public class CatalogController {

    @GetMapping("/{id}")
    public Map<String, Object> getProduct(@PathVariable String id) {
        return Map.of(
            "id", id,
            "name", "Zinger Burger",
            "price", 25.5
        );
    }
}
package com.example.demo;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.Map;
// GraphQL
@Controller
public class ItemGraphQLController {

    @QueryMapping
    public Map<String, Object> getItemById(@Argument String id) {
        return Map.of(
            "id", id,
            "name", "Zinger Burger",
            "price", 25.5
        );
    }
}